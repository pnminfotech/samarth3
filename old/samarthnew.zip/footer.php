
			<!-- Main Footer -->
			<footer class="main-footer">
				<div class="bg-image" style="background-image: url(./images/background/5.jpg)"></div>
				<div class="anim-icons">
					<span class="icon icon-plane-3 bounce-x"></span>
				</div>

		

				<!--Widgets Section-->
				<div class="widgets-section">
					<div class="auto-container">
						<div class="row">
							<!--Footer Column-->
							<div class="footer-column col-xl-4 col-lg-12 col-md-6 col-sm-12">
								<div class="footer-widget about-widget">
										<h3 class="widget-title">About</h3>
									<div class="text">Samarth Enterprises is a leading company engaged in the design, manufacture and supply of special cutting tools for Cutting, Drilling, Tapping, and Milling for Automobiles, Electrical Engineering, Leather, Petrochemicals Textile, Energy Sector, and Machine Tool Industries. </div>
									
								</div>
							</div>

							<!--Footer Column-->
							<div class="footer-column col-xl-5 col-lg-5 col-md-6 col-sm-12">
								<div class="footer-widget">
									<h3 class="widget-title">Product</h3>
									<div class="row">
									<div class="col-md-6">
									<ul class="user-links">
										<li><a href="milling-product.php">Milling Inserts</a></li>
										<li><a href="turning-product.php">Turning Inserts</a></li>
										<li><a href="grooving-product.php">Grooving Inserts</a></li>
										<li><a href="boring-product.php">Boring Inserts</a></li>
										
									</ul></div>
									<div class="col-md-6">
									<ul class="user-links">
										
										<li><a href="threading-product.php">Threading Inserts</a></li>
										<li><a href="aluminum-product.php">Aluminum  Inserts</a></li>
										<li><a href="solid-carbide-product.php">Solid Carbide Endmills</a></li>
										<li><a href="drilling-product.php">Drilling Insert</a></li>
									</ul></div></div>
								</div>
							</div>

							<!--Footer Column-->
						<!--Footer Column-->
							<div class="footer-column col-xl-3 col-lg-3 col-md-6 col-sm-12">
								<div class="footer-widget">
									<h3 class="widget-title">Get In Touch</h3>
									<div class="row">
									<div class="col-md-12">
									<div class="inner-box">
								
								
										<div class="text" style="color: #d7d7d9;"><i style="font-size:24px;" class="icon flaticon-international-shipping-2"></i> Shop No 1-,PAP j-155 ,near Quality Circle Fourm ,J block,Telco road bhosari Midc Pune 411026</div>
								   </div>
								   <div class="inner-box">
										<div class="text" style="color: #d7d7d9;"><i style="font-size:24px;"class="icon flaticon-stock-1"></i> +91 8446106747 / +91 8668284397</div>
								   </div>
								   <div class="inner-box">
										<div class="text" style="color: #d7d7d9;"><i style="font-size:24px;" class="icon flaticon-stock-1"></i> info@samarthenterpries.in</div>
								   </div>
									</div>
									</div>
								</div>
							</div>

						
						</div>
					</div>
				</div>

				<!--Footer Bottom-->
				<div class="footer-bottom">
					<div class="auto-container">
						<div class="inner-container">
							<div class="copyright-text">
								<p>&copy; Copyright 2023 by <a href="https://pnminfotech.com/">PNM Infotech</a></p>
							</div>

							<ul class="social-icon-two">
								<li>
									<a href="#"><i class="fab fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fab fa-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="fab fa-pinterest"></i></a>
								</li>
								<li>
									<a href="#"><i class="fab fa-instagram"></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
			<!--End Main Footer -->